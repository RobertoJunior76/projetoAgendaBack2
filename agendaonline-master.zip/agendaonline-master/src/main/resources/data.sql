
INSERT INTO agenda.contato(nome) VALUES('Maria');

COMMIT;